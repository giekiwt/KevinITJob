from django.contrib import admin
from .models import ProgrammingLanguage

admin.site.register(ProgrammingLanguage) 