from django.urls import path

urlpatterns = [
    # Add your blog endpoints here
] 