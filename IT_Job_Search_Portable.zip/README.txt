# IT Job Search - Portable Version

## Cách sử dụng:

1. **Chạy ứng dụng**: Double-click vào file `start_app.bat`
2. **Truy cập**: Mở trình duyệt và vào http://127.0.0.1:8000
3. **Dừng ứng dụng**: Nhấn Ctrl+C trong cửa sổ command

## Lưu ý:

- Lần đầu chạy sẽ mất thời gian để cài đặt các package
- Dữ liệu được lưu trong thư mục `data`
- Không cần cài đặt Python hay bất kỳ package nào khác

## Tính năng:

- Tìm kiếm việc làm IT
- Quản lý profile người dùng
- Blog về IT
- Responsive design
- Hơn 270 việc làm mẫu
- 20 công ty mẫu

## Hỗ trợ:

Nếu gặp vấn đề, hãy kiểm tra:
1. Windows Defender có chặn không
2. Port 8000 có bị sử dụng không
3. Quyền admin có cần thiết không
